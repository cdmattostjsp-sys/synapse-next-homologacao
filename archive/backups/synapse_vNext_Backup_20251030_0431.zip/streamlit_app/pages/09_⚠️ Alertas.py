# -*- coding: utf-8 -*-
"""
import sys, os
BASE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
if BASE_PATH not in sys.path:
    sys.path.append(BASE_PATH)
import sys, os
09_⚠️ Alertas.py – Painel de Alertas Proativos
==============================================================
Exibe resultados do módulo utils/alertas_pipeline.py,
com classificação por severidade, área e artefato.

Versão: SynapseNext vNext (TJSP/SAAB)
==============================================================
"""

import streamlit as st
from utils.alertas_pipeline import evaluate_alerts, export_alerts_json, DEFAULTS
from datetime import datetime
import json
import os

# --------------------------------------------------------------
# Configuração de página
# --------------------------------------------------------------
st.set_page_config(page_title="⚠️ Alertas Proativos", layout="wide")
st.title("⚠️ Painel de Alertas Proativos – SynapseNext vNext")
st.caption("Análise de auditoria, coerência e consistência documental.")

# --------------------------------------------------------------
# Seção lateral – parâmetros
# --------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Configurações de análise")
    st.write("Ajuste os parâmetros e reexecute a avaliação:")

    min_coerencia_global = st.slider(
        "Coerência Global mínima (%)", 50, 100, DEFAULTS["min_coerencia_global"]
    )
    min_pairwise = st.slider(
        "Coerência par-a-par mínima (%)", 50, 100, DEFAULTS["min_pairwise"]
    )
    max_staleness_days = st.slider(
        "Máx. dias sem auditoria", 1, 30, DEFAULTS["max_staleness_days"]
    )
    max_wc_change_pct = st.slider(
        "Máx. variação de tamanho (%)", 5, 100, DEFAULTS["max_wc_change_pct"]
    )

    cfg = {
        "min_coerencia_global": min_coerencia_global,
        "min_pairwise": min_pairwise,
        "max_staleness_days": max_staleness_days,
        "max_wc_change_pct": max_wc_change_pct,
    }

    if st.button("🔍 Reexecutar análise", use_container_width=True):
        st.session_state["alertas_result"] = evaluate_alerts(cfg)
        st.success("✅ Análise reexecutada com sucesso.")


# --------------------------------------------------------------
# Execução principal
# --------------------------------------------------------------
if "alertas_result" not in st.session_state:
    st.session_state["alertas_result"] = evaluate_alerts(DEFAULTS)

resultado = st.session_state["alertas_result"]
totais = resultado.get("totais", {})
alertas = resultado.get("alerts", [])
ts = resultado.get("timestamp", datetime.now().strftime("%d/%m/%Y %H:%M:%S"))

# --------------------------------------------------------------
# Cabeçalho de resumo
# --------------------------------------------------------------
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total de Alertas", totais.get("geral", 0))
col2.metric("Alta Severidade", totais.get("alto", 0))
col3.metric("Média Severidade", totais.get("medio", 0))
col4.metric("Baixa Severidade", totais.get("baixo", 0))
st.caption(f"Última atualização: {ts}")

# --------------------------------------------------------------
# Tabela de alertas
# --------------------------------------------------------------
if not alertas:
    st.info("✅ Nenhum alerta ativo no momento. Todos os artefatos estão coerentes e atualizados.")
else:
    st.divider()
    st.subheader("📋 Lista de alertas detectados")

    for a in alertas:
        color = {
            "alto": "🔴",
            "medio": "🟠",
            "baixo": "🟡",
        }.get(a["severidade"], "⚪")

        with st.expander(f"{color} {a['titulo']} ({a['area']})"):
            st.markdown(f"**Artefato:** {a.get('artefato', '-')}")
            st.markdown(f"**Detalhe:** {a['detalhe']}")
            st.markdown(f"**Recomendação:** {a['recomendacao']}")
            st.markdown(f"**Timestamp:** {a['timestamp']}")

# --------------------------------------------------------------
# Exportação
# --------------------------------------------------------------
st.divider()
if st.button("💾 Exportar alertas para JSON", use_container_width=True):
    path = export_alerts_json(resultado)
    st.success(f"✅ Arquivo exportado com sucesso: `{os.path.basename(path)}`")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    st.download_button(
        label="⬇️ Baixar arquivo JSON",
        data=json.dumps(data, indent=2, ensure_ascii=False),
        file_name=os.path.basename(path),
        mime="application/json",
    )

st.caption("Sistema SynapseNext vNext – Secretaria de Administração e Abastecimento (SAAB/TJSP)")