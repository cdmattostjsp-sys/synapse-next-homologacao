import sys, os
BASE_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
if BASE_PATH not in sys.path:
    sys.path.append(BASE_PATH)
import sys, os
import streamlit as st
from utils.ui_components import aplicar_estilo_global, exibir_cabecalho_padrao
from utils.agents_bridge import AgentsBridge
from io import BytesIO
from docx import Document
import json
import os

# ==========================================================
# 📘 ETP – Estudo Técnico Preliminar
# SynapseNext – Secretaria de Administração e Abastecimento (TJSP)
# ==========================================================
st.set_page_config(page_title="📘 ETP – Estudo Técnico Preliminar", layout="wide", page_icon="📘")
aplicar_estilo_global()

exibir_cabecalho_padrao(
    "📘 Estudo Técnico Preliminar (ETP)",
    "Geração automatizada com IA institucional a partir da DFD"
)
st.divider()

# ==========================================================
# 🔍 Recupera dados da DFD, se disponíveis
# ==========================================================
dfd_data = st.session_state.get("last_dfd", {})

if dfd_data:
    st.success("📎 DFD detectado. Dados serão usados como base para o ETP.")
    with st.expander("🧾 Visualizar DFD ativo"):
        st.json(dfd_data)
else:
    st.info("Nenhum DFD ativo encontrado. Você pode preencher o ETP manualmente.")
st.divider()

# ==========================================================
# 🧾 Formulário Institucional ETP
# ==========================================================
st.subheader("1️⃣ Entrada – Dados Técnicos")

with st.form("form_etp"):
    objeto = st.text_area("Objeto da contratação", value=dfd_data.get("objeto", ""), height=80)
    justificativa = st.text_area("Justificativa técnica", value=dfd_data.get("justificativa", ""), height=100)
    solucoes = st.text_area("Soluções de mercado identificadas", height=100)
    requisitos = st.text_area("Requisitos mínimos e desempenho esperado", height=100)
    estimativa = st.text_area("Estimativa de custos", height=80)
    riscos = st.text_area("Riscos associados", height=80)
    responsavel = st.text_input("Responsável técnico", value="")
    gerar_ia = st.form_submit_button("⚙️ Gerar rascunho com IA institucional")
    submitted = st.form_submit_button("💾 Gerar rascunho manual")

# ==========================================================
# ⚙️ Geração IA Institucional
# ==========================================================
if gerar_ia:
    st.info("Executando agente ETP institucional...")
    metadata = {
        "objeto": objeto,
        "justificativa_tecnica": justificativa,
        "solucoes_mercado": solucoes,
        "requisitos": requisitos,
        "estimativa_custos": estimativa,
        "riscos": riscos,
        "responsavel": responsavel,
    }
    try:
        bridge = AgentsBridge("ETP")
        resultado = bridge.generate(metadata)
        st.success("✅ Rascunho gerado com sucesso pelo agente ETP.IA!")
        st.json(resultado)
        st.session_state["last_etp"] = resultado.get("secoes", {})
    except Exception as e:
        st.error(f"Erro ao gerar rascunho com IA: {e}")

# ==========================================================
# 💾 Geração manual
# ==========================================================
if submitted:
    etp_data = {
        "objeto": objeto,
        "justificativa_tecnica": justificativa,
        "solucoes_mercado": solucoes,
        "requisitos": requisitos,
        "estimativa_custos": estimativa,
        "riscos": riscos,
        "responsavel": responsavel,
    }
    st.success("✅ Rascunho de ETP gerado manualmente!")
    st.json(etp_data)
    st.session_state["last_etp"] = etp_data

# ==========================================================
# 📤 Exportação
# ==========================================================
if "last_etp" in st.session_state and st.session_state["last_etp"]:
    st.divider()
    st.subheader("📤 Exportação de Documento")
    st.info("Baixe o último ETP gerado em formato Word editável.")

    etp_data = st.session_state["last_etp"]
    doc = Document()
    doc.add_heading("Estudo Técnico Preliminar (ETP)", level=1)
    for k, v in etp_data.items():
        p = doc.add_paragraph()
        p.add_run(f"{k}: ").bold = True
        p.add_run(str(v) or "—")

    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    st.download_button("💾 Baixar ETP_rascunho.docx", buffer, file_name="ETP_rascunho.docx")

    if st.button("📦 Exportar ETP (JSON)"):
        out_dir = "exports"
        os.makedirs(out_dir, exist_ok=True)
        path = os.path.join(out_dir, "etp_teste.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(etp_data, f, ensure_ascii=False, indent=2)
        st.success(f"✅ ETP exportado com sucesso para {path}")

st.caption("💡 *Dica:* O botão '⚙️ Gerar rascunho com IA institucional' usa o agente ETP.IA para gerar automaticamente o texto técnico.")