# knowledge/validators/__init__.py
# Marca este diretório como um pacote Python.
